```markdown
# Design System Specification: The Digital Sanctuary

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Scholarly Atrium."** 

Moving away from the frantic, high-intensity aesthetics of modern "productivity" apps, this system embraces a "Global Humanist" philosophy. It treats the digital interface not as a tool, but as a physical space—a quiet, sun-drenched library where cognitive growth is nurtured through focus and serenity. 

To break the "template" look, we reject the rigid, boxed-in layouts of standard SaaS. We favor **intentional asymmetry**, wide-reaching margins, and an editorial approach to information density. Elements should feel like they are "resting" on a surface rather than being "latched" to a grid. We replace aggressive borders with tonal shifts, creating a UI that feels curated, premium, and human-centric.

---

## 2. Colors & Surface Philosophy
The palette is rooted in organic, historical tones: the deep indigo of leather-bound books, the warmth of aged parchment, and the calming influence of botanical sage.

### The "No-Line" Rule
Standard 1px borders are strictly prohibited for sectioning. Structural definition must be achieved through **Background Color Shifts** only. For example, a card should not have an outline; it should be a `surface-container-lowest` element sitting on a `surface-container-low` background.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked, fine papers.
- **Base Layer:** `surface` (#fef9f0) – The primary canvas.
- **Structural Sections:** `surface-container` (#f2ede4) – Used for sidebars or distinct page regions.
- **Interactive Elements:** `surface-container-highest` (#e7e2d9) – For inputs or focused containers.
- **Elevation:** Use `surface-bright` for elements that need to feel "closer" to the user, creating depth through light, not lines.

### Signature Textures & Soul
To avoid a flat, "clinical" feel, use a subtle **linear gradient** for primary CTAs: 
*   From `primary` (#03192e) to `primary_container` (#1a2e44) at a 145° angle. This adds a "weighted" quality to buttons, mimicking the depth of high-end ink.

---

## 3. Typography: The Editorial Voice
We use a dual-typeface system to balance modern accessibility with classical authority.

*   **Display & Headlines (Noto Serif):** Used for all `display` and `headline` levels. This serif provides a "Humanist" anchor, making the app feel like a premium publication. It signals a moment of reflection.
*   **Interface & Body (Manrope):** Used for `title`, `body`, and `label` levels. Manrope’s geometric yet warm proportions ensure high legibility for cognitive exercises while remaining modern and clean.

**Typographic Intent:**
- **Asymmetric Headers:** Pair a `display-lg` headline with a wide left margin, allowing the `body-md` text to sit offset, creating an editorial, non-linear flow.
- **Leading:** Increase line-height for `body-lg` to **1.6** to ensure a "breathable" reading experience.

---

## 4. Elevation & Depth
In a Digital Sanctuary, shadows represent natural ambient light, not digital "glow."

### Tonal Layering
Primary hierarchy is achieved by "stacking" the surface-container tiers. Place a `surface-container-lowest` card (#ffffff) on a `surface-container-low` (#f8f3ea) section to create a soft, natural lift.

### Ambient Shadows
Where floating elements (like Modals or Fab) are required, use the following:
- **Blur:** 24px - 40px
- **Opacity:** 4% - 6%
- **Color:** A tinted `on-surface` (#1d1c16). 
- **Instruction:** Never use pure black or grey shadows. The shadow must feel like a "soft stain" on the parchment background.

### The Ghost Border Fallback
If accessibility requirements demand a border (e.g., in high-contrast modes), use `outline-variant` (#c4c6cd) at **15% opacity**. A 100% opaque border is a failure of the system's "Soft Professionalism."

---

## 5. Components

### Buttons
- **Primary:** Gradient fill (`primary` to `primary_container`), `on-primary` text. Rounding: `md` (0.75rem).
- **Secondary:** `secondary_container` fill with `on-secondary-container` text. No border.
- **Tertiary:** Text-only in `primary` color. Use for low-emphasis actions.

### Cards & Lists
- **Rule:** Forbid divider lines. 
- **Implementation:** Separate list items using **Spacing Scale 3** (1rem) or by alternating background colors between `surface` and `surface-container-low`.
- **Rounding:** Use `lg` (1rem) for content cards to maintain a gentle, organic feel.

### Input Fields
- **Style:** Understated. Use `surface-container-highest` as the fill. 
- **Focus State:** Instead of a heavy border, use a 2px bottom-bar in `primary` (#03192e) and a subtle shift in background brightness.

### The "Focus Shield" (Custom Component)
A large, `xl` rounded container using a backdrop-blur of 10px and a 20% transparent `surface` fill. Used for cognitive exercises to "blur out" the rest of the interface, creating a sanctuary within the app.

---

## 6. Do's and Don'ts

### Do:
*   **Use White Space as a Tool:** Use `spacing-16` (5.5rem) or `spacing-20` (7rem) between major sections to let the mind rest.
*   **Embrace Asymmetry:** Align a title to the left and the description to the right of the center-axis to create a high-end, custom-designed feel.
*   **Layer Tones:** Always place lighter surfaces on darker "container" backgrounds to create a sense of physical importance.

### Don't:
*   **Don't use Neon:** Avoid any high-vibrancy colors. If a status is "Success," use the `secondary` sage green (#4d635f), not a bright "matrix" green.
*   **Don't use Hard Corners:** Avoid `none` or `sm` rounding for main UI elements. We are building a sanctuary, not a laboratory.
*   **Don't use Dividers:** If you feel the need to add a line, try adding `1.4rem` of space (Spacing Scale 4) or a 1-step shift in the `surface-container` color instead.

---

## 7. Spacing & Rhythm
The system uses a bespoke spacing scale to ensure "Breathing Room." 
- **Standard Padding:** Use `spacing-5` (1.7rem) for card internals.
- **Section Gaps:** Use `spacing-12` (4rem) to separate cognitive modules.
- **The "Library" Margin:** On desktop views, maintain a minimum side margin of `spacing-20` (7rem) to keep content centered and focused, mimicking the margins of a luxury hardcover book.```